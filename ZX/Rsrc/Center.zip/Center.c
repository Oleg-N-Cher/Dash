#include <dos.h>

static volatile unsigned elapsed;
static unsigned ttyx = 0, ttyy = 0;
typedef unsigned char letter_line[2];
typedef letter_line letter[12];			/*Letter for text 16x32*/
static letter * signer;	/*malloced in further*/

static void interrupt (*std_timer)(void);

static void interrupt timer_handler (void)
{{	/*serve vector 0x1C*/
 if (elapsed) elapsed --;
}}

void cdecl end_time (void)
{{
  setvect (0x1C, std_timer);
}}

void init_time (void)
{{
  std_timer = getvect (0x1C);
  setvect (0x1C, timer_handler);
  elapsed = 0;
  atexit (end_time);
}}

void run_delay (unsigned ticks)
{{
  elapsed = ticks;
}}

void wait_delay (void)
{{
  while (elapsed)	;
}}

static unsigned const seg = 0xB800;

void cls (void)
{{
 unsigned char _es* i;
 unsigned j;

 _ES = seg;
 i = 0;
 for (j = 17; j; j--) {
  run_delay (1);
  while ((unsigned)i < 16384)
   *i = 0, i += 17;
  i = (unsigned char _es*)(0x3FFF & (unsigned)i);
  wait_delay ();
   }
 ttyx = ttyy = 0;
}}

static void lmove (unsigned to, unsigned from)
/*��������� (�����������) ����� from � to*/
{{
 struct line {char __[80];};
 struct line _es * Lto;
 struct line _es * Lfrom;

 if (to == from || !(to < 192 && from < 192))
  return;
 _ES = seg;
 to += 4;
 from += 4;
 Lto = (struct line _es *)((to >> 1) * 80 + ((to & 1) << 13));
 Lfrom = (struct line _es *)((from >> 1) * 80 + ((from & 1) << 13));
 *Lto = *Lfrom;
}}

static void lclr (unsigned line)
/*������� ����� ������ � ������ �������*/
{{
 unsigned e = line;
 long _es* L;

 if (e < 192) {
  e += 4;
  _ES = seg;
  L = (long _es*)((e >> 1) * 80 + ((e & 1) << 13));
  for (e = 20; e; e--)
   *L ++ = 0;
   }
}}

void scroll (signed lines)
/* +UP, -DOWN */
{{
 unsigned media, line;

 if (lines == 0)
  return;
 if (abs (lines) >= 192) {
  cls ();
  return;
   }
 if (lines > 0) {
  media = 192 - lines;
  for (line = 0; line < media; line ++)
   lmove (line, line + lines);
  while (line < 192)
   lclr (line ++);
   }
 else {
  media = -lines;
  for (line = 191; line >= media; line --)
   lmove (line, line + lines);
  while (line < 192)
   lclr (line --);
   }
}}

void emt16 (char c)
{{
 unsigned * llt = (unsigned *)(signer + c);
 unsigned _es * vbase;
 int i;

 vbase = (unsigned _es *)((ttyx << 1) + (((ttyy << 4) - ttyy) << 5) + 168);
 _ES = seg;

 for (i = 0; i < 12; i += 2, vbase += 40) {
  vbase[0] = *llt ++;
  vbase[4096] = *llt ++;
   }
 if (++ttyx == 32) {	/*������� �� ����� ������*/
  ttyx = 0;
  if (++ ttyy == 16) {	/*����� ��� ���������� ����� ������*/
   ttyy = 15;
   scroll (+12);
    }
   }
}}

void print_asciz (char * str)
{{
 while (*str)
  emt16 (*str++);
}}

void locate (unsigned line, unsigned pos)
{{
 if (pos < 32)
  ttyx = pos;
 if (line < 16)
  ttyy = line;
}}
/*
void center (unsigned line, char * s)
{{
 int i = 0, j = strlen (s), k;

 locate (line, 0);
 k = 16 - (j >> 1);
 while (i ++ < k)
  emt16 (' ');
 print_asciz (s);
 k += j;
 while (++ k < 32)
  emt16 ('!');
}}
*/
void center (unsigned line, char * s)
{{
 int i = 0, j = strlen (s), k;

 locate (line, 0);
 k = 16 - (j >> 1);
 while (i ++ < k)
  printf("%d ", i-1);
 printf("%s", s); printf(" ");
 k += j;
 while (++ k < 32)
  printf("%d ", k-1);
}}

static void press_any_key (void)
{{
 center (13, "Press any key ..Press any key .."); printf("\n");
 center (14, "Press any key ..."); printf("\n");
 center (15, "Press any key ...");
 /*print_asciz(" ");*/

 _AX = 0;
 geninterrupt (0x16);
}}

void main (int argc, char * argv[])
{{
  /*_AX = 0x0004;
  geninterrupt (0x10);
  init_time();
  cls();*/
  press_any_key();
  /*end_time();
  _AX = 0x0003;
  geninterrupt (0x10);*/
}}

