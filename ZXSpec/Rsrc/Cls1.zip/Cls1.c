#include <dos.h>

static volatile unsigned elapsed;

static void interrupt (*std_timer)(void);

static void interrupt timer_handler (void)
{{	/*serve vector 0x1C*/
 if (elapsed) elapsed --;
}}

void cdecl end_time (void)
{{
  setvect (0x1C, std_timer);
}}

void init_time (void)
{{
  std_timer = getvect (0x1C);
  setvect (0x1C, timer_handler);
  elapsed = 0;
  atexit (end_time);
}}

void run_delay (unsigned ticks)
{{
  elapsed = ticks;
}}

void wait_delay (void)
{{
  while (elapsed)	;
}}

static unsigned const seg = 0xB800;

void cls (void)
{{
 unsigned char _es* i;
 unsigned j;

 _ES = seg;
 i = 0;
 for (j = 17; j; j--) {
  run_delay (10);
  while ((unsigned)i < 16384) {
   *i = 0xFF, i += 17;
     _AX = 0;
     geninterrupt (0x16);
  }
  i = (unsigned char _es*)(0x3FFF & (unsigned)i);
  wait_delay ();
   }
}}

void main (int argc, char * argv[])
{{
  _AX = 0x0004;
  geninterrupt (0x10);
  init_time();
  cls();
  end_time();
  _AX = 0x0003;
  geninterrupt (0x10);
}}

